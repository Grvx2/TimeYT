"use strict";

(() => {
  const DATABASE_NAME = "vtm-local-history";
  const DATABASE_VERSION = 3;
  const VIDEO_STORE = "videos";
  const SESSION_STORE = "sessions";
  const SETTINGS_STORE = "settings";
  const PLAYBACK_STORE = "playback";
  const PLAYBACK_OWNER_KEY = "owner";
  const PLAYBACK_OWNER_LEASE_MS = 2_500;
  let databasePromise;

  function openDatabase() {
    if (databasePromise) return databasePromise;

    databasePromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);

      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(VIDEO_STORE)) {
          const videos = database.createObjectStore(VIDEO_STORE, {
            keyPath: ["date", "hour", "videoId"],
          });
          videos.createIndex("date", "date", { unique: false });
          videos.createIndex("videoId", "videoId", { unique: false });
          videos.createIndex("channelId", "channelId", { unique: false });
        }
        let sessions;
        if (!database.objectStoreNames.contains(SESSION_STORE)) {
          sessions = database.createObjectStore(SESSION_STORE, { keyPath: "sessionId" });
        } else {
          sessions = request.transaction.objectStore(SESSION_STORE);
        }
        if (!sessions.indexNames.contains("lastSeen")) {
          sessions.createIndex("lastSeen", "lastSeen", { unique: false });
        }
        if (!database.objectStoreNames.contains(SETTINGS_STORE)) {
          database.createObjectStore(SETTINGS_STORE, { keyPath: "key" });
        }
        if (!database.objectStoreNames.contains(PLAYBACK_STORE)) {
          database.createObjectStore(PLAYBACK_STORE, { keyPath: "key" });
        }
      };

      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = () => database.close();
        resolve(database);
      };
      request.onerror = () => {
        databasePromise = undefined;
        reject(request.error ?? new Error("Nie udało się otworzyć lokalnej bazy danych."));
      };
      request.onblocked = () => {
        databasePromise = undefined;
        reject(new Error("Lokalna baza jest zablokowana przez inną kartę. Zamknij karty rozszerzenia i spróbuj ponownie."));
      };
    });

    return databasePromise;
  }

  function validChannelUrl(value) {
    if (typeof value !== "string") return false;
    try {
      const url = new URL(value);
      return url.protocol === "https:"
        && ["www.youtube.com", "youtube.com"].includes(url.hostname)
        && /^\/(?:channel\/[\w-]+|@[\w.-]+|c\/[\w.-]+|user\/[\w.-]+)\/?$/.test(url.pathname);
    } catch {
      return false;
    }
  }

  function waitForTransaction(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = resolve;
      transaction.onabort = () => reject(transaction.error ?? new Error("Transakcja lokalnej bazy danych została przerwana."));
      transaction.onerror = () => reject(transaction.error ?? new Error("Błąd zapisu w lokalnej bazie danych."));
    });
  }

  function validVideoId(videoId) {
    return typeof videoId === "string" && /^[\w-]{6,20}$/.test(videoId);
  }

  function validDate(date) {
    if (typeof date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
    const parsed = new Date(`${date}T00:00:00Z`);
    return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === date;
  }

  function cleanText(value, maximumLength = 300) {
    return typeof value === "string" ? value.trim().slice(0, maximumLength) : "";
  }

  function normalizeVideoRecord(record) {
    if (!record || !validDate(record.date) || !validVideoId(record.videoId)) {
      throw new Error("Plik zawiera nieprawidłowy wpis historii.");
    }
    const hour = Number(record.hour);
    const seconds = Number(record.seconds);
    const mediaSeconds = record.mediaSeconds === undefined ? seconds : Number(record.mediaSeconds);
    if (!Number.isInteger(hour) || hour < 0 || hour > 23
      || !Number.isFinite(seconds) || seconds < 0 || seconds > 3_660
      || !Number.isFinite(mediaSeconds) || mediaSeconds < 0 || mediaSeconds > 60_000) {
      throw new Error("Plik zawiera nieprawidłowy czas oglądania.");
    }
    if (seconds === 0 && mediaSeconds === 0) throw new Error("Wpis historii musi zawierać zapisany czas.");

    return {
      date: record.date,
      hour,
      videoId: record.videoId,
      title: cleanText(record.title),
      channelId: cleanText(record.channelId, 100),
      channelName: cleanText(record.channelName),
      channelUrl: validChannelUrl(record.channelUrl) ? record.channelUrl : "",
      channelIconUrl: validChannelIcon(record.channelIconUrl) ? record.channelIconUrl : "",
      videoType: ["video", "short", "live"].includes(record.videoType) ? record.videoType : "video",
      durationSeconds: Number.isFinite(Number(record.durationSeconds))
        ? Math.max(0, Number(record.durationSeconds))
        : 0,
      seconds,
      mediaSeconds,
      url: `https://www.youtube.com/watch?v=${encodeURIComponent(record.videoId)}`,
    };
  }

  function validChannelIcon(value) {
    if (typeof value !== "string") return false;
    try {
      const url = new URL(value);
      return url.protocol === "https:"
        && ["yt3.ggpht.com", "yt3.googleusercontent.com"].includes(url.hostname);
    } catch {
      return false;
    }
  }

  async function saveWatchEvent(event, tabId = null) {
    if (!event || typeof event.sessionId !== "string" || event.sessionId.length > 100
      || !Number.isSafeInteger(event.sequence) || event.sequence < 1) {
      throw new Error("Nieprawidłowy identyfikator zapisu.");
    }
    if (!Number.isFinite(event.seconds) || event.seconds <= 0 || event.seconds > 15
      || (event.mediaSeconds !== undefined
        && (!Number.isFinite(event.mediaSeconds) || event.mediaSeconds < 0 || event.mediaSeconds > 240))) {
      throw new Error("Nieprawidłowa długość interwału oglądania.");
    }
    const record = normalizeVideoRecord(event);
    const database = await openDatabase();
    const transaction = database.transaction([VIDEO_STORE, SESSION_STORE, PLAYBACK_STORE], "readwrite");
    const videos = transaction.objectStore(VIDEO_STORE);
    const sessions = transaction.objectStore(SESSION_STORE);
    const playback = transaction.objectStore(PLAYBACK_STORE);
    const completion = waitForTransaction(transaction);
    let savedSeconds = 0;
    let duplicate = false;

    sessions.get(event.sessionId).onsuccess = (result) => {
      const previous = result.target.result;
      const lastSequence = previous?.lastSequence ?? 0;
      if (event.sequence <= lastSequence) {
        duplicate = true;
        return;
      }
      if (event.sequence !== lastSequence + 1) {
        transaction.abort();
        return;
      }
      if (event.sequence === 1) {
        const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
        sessions.index("lastSeen").openCursor(IDBKeyRange.upperBound(cutoff)).onsuccess = (cursorEvent) => {
          const cursor = cursorEvent.target.result;
          if (!cursor) return;
          cursor.delete();
          cursor.continue();
        };
      }

      const saveRecord = (watchSeconds) => {
        savedSeconds = watchSeconds;
        const key = [record.date, record.hour, record.videoId];
        videos.get(key).onsuccess = (videoResult) => {
          const existing = videoResult.target.result;
          videos.put({
            ...existing,
            ...record,
            title: record.title || existing?.title || "",
            channelId: record.channelId || existing?.channelId || "",
            channelName: record.channelName || existing?.channelName || "",
            channelUrl: record.channelUrl || existing?.channelUrl || "",
            channelIconUrl: record.channelIconUrl || existing?.channelIconUrl || "",
            durationSeconds: record.durationSeconds || existing?.durationSeconds || 0,
            seconds: (existing?.seconds ?? 0) + watchSeconds,
            mediaSeconds: (existing?.mediaSeconds ?? existing?.seconds ?? 0) + record.mediaSeconds,
          });
          sessions.put({
            sessionId: event.sessionId,
            lastSequence: event.sequence,
            lastSeen: Date.now(),
          });
        };
      };

      if (!Number.isInteger(tabId) || tabId < 0) {
        saveRecord(record.seconds);
        return;
      }
      playback.get(PLAYBACK_OWNER_KEY).onsuccess = (ownerResult) => {
        const now = Date.now();
        const owner = ownerResult.target.result;
        const ownsPlayback = !owner || now - owner.lastSeen > PLAYBACK_OWNER_LEASE_MS
          || owner.tabId === tabId;
        if (ownsPlayback) {
          playback.put({ key: PLAYBACK_OWNER_KEY, tabId, lastSeen: now });
        }
        saveRecord(ownsPlayback ? record.seconds : 0);
      };
    };

    await completion;
    return { seconds: savedSeconds, duplicate };
  }

  async function releasePlaybackOwner(tabId) {
    if (!Number.isInteger(tabId) || tabId < 0) return false;
    const database = await openDatabase();
    const transaction = database.transaction(PLAYBACK_STORE, "readwrite");
    const playback = transaction.objectStore(PLAYBACK_STORE);
    const completion = waitForTransaction(transaction);
    let released = false;
    playback.get(PLAYBACK_OWNER_KEY).onsuccess = (result) => {
      if (result.target.result?.tabId !== tabId) return;
      playback.delete(PLAYBACK_OWNER_KEY);
      released = true;
    };
    await completion;
    return released;
  }

  async function listHistory(fromDate, toDate) {
    if (!validDate(fromDate) || !validDate(toDate) || fromDate > toDate) {
      throw new Error("Nieprawidłowy zakres dat historii.");
    }
    const database = await openDatabase();
    const transaction = database.transaction(VIDEO_STORE, "readonly");
    const completion = waitForTransaction(transaction);
    const request = transaction.objectStore(VIDEO_STORE).index("date")
      .getAll(IDBKeyRange.bound(fromDate, toDate));
    const records = await new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("Nie udało się odczytać historii."));
    });
    await completion;
    return records;
  }

  async function getAllHistory() {
    const database = await openDatabase();
    const transaction = database.transaction(VIDEO_STORE, "readonly");
    const completion = waitForTransaction(transaction);
    const request = transaction.objectStore(VIDEO_STORE).getAll();
    const records = await new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("Nie udało się odczytać historii."));
    });
    await completion;
    return records;
  }

  async function importHistory(records) {
    if (!Array.isArray(records) || records.length === 0) {
      throw new Error("Plik nie zawiera wpisów historii do zaimportowania.");
    }

    const normalizedRecords = new Map();
    for (const [index, sourceRecord] of records.entries()) {
      let record;
      try {
        record = normalizeVideoRecord(sourceRecord);
      } catch (error) {
        throw new Error(`Nieprawidłowy wpis historii nr ${index + 1}: ${error.message}`);
      }
      const key = [record.date, record.hour, record.videoId];
      const keyId = JSON.stringify(key);
      const previous = normalizedRecords.get(keyId);
      if (previous) {
        previous.seconds = Math.max(previous.seconds, record.seconds);
        previous.mediaSeconds = Math.max(previous.mediaSeconds, record.mediaSeconds);
        previous.title ||= record.title;
        previous.channelId ||= record.channelId;
        previous.channelName ||= record.channelName;
        previous.channelUrl ||= record.channelUrl;
        previous.channelIconUrl ||= record.channelIconUrl;
        previous.durationSeconds ||= record.durationSeconds;
      } else {
        normalizedRecords.set(keyId, record);
      }
    }

    const database = await openDatabase();
    const transaction = database.transaction(VIDEO_STORE, "readwrite");
    const completion = waitForTransaction(transaction);
    const videos = transaction.objectStore(VIDEO_STORE);
    let added = 0;
    let updated = 0;
    let unchanged = 0;

    for (const record of normalizedRecords.values()) {
      const request = videos.get([record.date, record.hour, record.videoId]);
      request.onsuccess = () => {
        const existing = request.result;
        if (!existing) {
          videos.put(record);
          added += 1;
          return;
        }
        const merged = {
          ...existing,
          ...record,
          title: record.title || existing.title,
          channelId: record.channelId || existing.channelId,
          channelName: record.channelName || existing.channelName,
          channelUrl: record.channelUrl || existing.channelUrl,
          channelIconUrl: record.channelIconUrl || existing.channelIconUrl,
          durationSeconds: record.durationSeconds || existing.durationSeconds,
          seconds: Math.max(existing.seconds, record.seconds),
          mediaSeconds: Math.max(existing.mediaSeconds ?? existing.seconds, record.mediaSeconds),
        };
        if (JSON.stringify(merged) === JSON.stringify(existing)) {
          unchanged += 1;
        } else {
          videos.put(merged);
          updated += 1;
        }
      };
    }

    await completion;
    return { added, updated, unchanged, total: normalizedRecords.size };
  }

  async function getFirstHistoryDate() {
    const database = await openDatabase();
    const transaction = database.transaction(VIDEO_STORE, "readonly");
    const completion = waitForTransaction(transaction);
    const request = transaction.objectStore(VIDEO_STORE).index("date").openCursor();
    const firstDate = await new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result?.value.date ?? null);
      request.onerror = () => reject(request.error ?? new Error("Nie udało się znaleźć początku historii."));
    });
    await completion;
    return firstDate;
  }

  async function getSetting(key, fallback) {
    const database = await openDatabase();
    const transaction = database.transaction(SETTINGS_STORE, "readonly");
    const request = transaction.objectStore(SETTINGS_STORE).get(key);
    const result = await new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("Nie udało się odczytać ustawienia."));
    });
    return result ? result.value : fallback;
  }

  async function setSetting(key, value) {
    const database = await openDatabase();
    const transaction = database.transaction(SETTINGS_STORE, "readwrite");
    transaction.objectStore(SETTINGS_STORE).put({ key, value });
    await waitForTransaction(transaction);
  }

  globalThis.VtmStorage = Object.freeze({
    getAllHistory,
    getFirstHistoryDate,
    getSetting,
    importHistory,
    listHistory,
    openDatabase,
    releasePlaybackOwner,
    saveWatchEvent,
    setSetting,
  });
})();
