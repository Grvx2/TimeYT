"use strict";

(() => {
  const output = document.querySelector("#results");
  const checks = [];
  const assert = (condition, message) => {
    if (!condition) throw new Error(message);
    checks.push(`OK ${message}`);
  };

  async function clearTestDatabase() {
    const database = await VtmStorage.openDatabase();
    const transaction = database.transaction(["videos", "sessions", "settings", "playback"], "readwrite");
    for (const store of ["videos", "sessions", "settings", "playback"]) transaction.objectStore(store).clear();
    await new Promise((resolve, reject) => {
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  }

  async function run() {
    await clearTestDatabase();
    const base = {
      date: "2026-10-04",
      hour: 11,
      videoId: "abcdefghijk",
      title: "Test film",
      channelId: "UC-test",
      channelName: "Kanał testowy",
      channelIconUrl: "https://yt3.ggpht.com/test-avatar",
      videoType: "video",
      durationSeconds: 120,
      sessionId: "smoke-test-session",
    };

    await VtmStorage.saveWatchEvent({ ...base, sequence: 1, seconds: 3, mediaSeconds: 6 });
    await VtmStorage.saveWatchEvent({ ...base, sequence: 1, seconds: 3, mediaSeconds: 6 });
    let rows = await VtmStorage.listHistory("2026-10-04", "2026-10-04");
    assert(rows.length === 1 && rows[0].seconds === 3, "Ponowiony event nie dubluje zapisanego czasu.");

    await VtmStorage.saveWatchEvent({ ...base, sequence: 2, seconds: 2.5, mediaSeconds: 5 });
    rows = await VtmStorage.listHistory("2026-10-04", "2026-10-04");
    assert(rows[0].seconds === 5.5, "Kolejny event atomowo zwiększa czas filmu.");
    assert(rows[0].mediaSeconds === 11, "Czas rzeczywisty i czas filmu są sumowane niezależnie.");
    await VtmStorage.saveWatchEvent({ ...base, channelIconUrl: "", sequence: 3, seconds: 1, mediaSeconds: 2 });
    rows = await VtmStorage.listHistory("2026-10-04", "2026-10-04");
    assert(rows[0].channelIconUrl === base.channelIconUrl, "Późniejszy event bez awatara nie kasuje zapisanego awatara kanału.");
    assert(rows[0].seconds === 6.5 && rows[0].mediaSeconds === 13, "Wpis z przyspieszeniem x2 zachowuje oddzielne sumy.");
    await VtmStorage.saveWatchEvent({ ...base, videoId: "legacy123", sessionId: "legacy-smoke-session", sequence: 1, seconds: 2 });
    rows = await VtmStorage.listHistory("2026-10-04", "2026-10-04");
    assert(rows.find((row) => row.videoId === "legacy123").mediaSeconds === 2, "Starsze zapisy bez osobnego czasu filmu zachowują poprawny czas domyślny.");
    assert(await VtmStorage.getFirstHistoryDate() === "2026-10-04", "Data pierwszego zapisu jest dostępna dla filtra wykresu.");
    await VtmStorage.setSetting("appearance-mode", "light");
    assert(await VtmStorage.getSetting("appearance-mode", "dark") === "light", "Ustawienia wyglądu są trwale zapisywane lokalnie.");
    await VtmStorage.setSetting("show-media-time", true);
    await VtmStorage.setSetting("chart-scale-week", "sinceStart");
    await VtmStorage.setSetting("compact-all-chart", true);
    await VtmStorage.setSetting("duration-format", "always-seconds");
    assert(
      await VtmStorage.getSetting("show-media-time", false)
        && await VtmStorage.getSetting("chart-scale-week", "visible") === "sinceStart"
        && await VtmStorage.getSetting("compact-all-chart", false)
        && await VtmStorage.getSetting("duration-format", "") === "always-seconds",
      "Ustawienia dodatkowego czasu filmu, skali wykresu i kompaktowego All są trwale zapisywane.",
    );
    await VtmStorage.setSetting("youtube-button-delay", 500);
    await VtmStorage.setSetting("youtube-button-scale", 40);
    assert(
      await VtmStorage.getSetting("youtube-button-delay", 0) === 500
        && await VtmStorage.getSetting("youtube-button-scale", 0) === 40,
      "Opóźnienie ikonki i maksymalna wysokość jej obrazu są trwale zapisywane lokalnie.",
    );
    await VtmStorage.setSetting("youtube-button-image", "data:image/png;base64,dGVzdA==");
    assert(
      await VtmStorage.getSetting("youtube-button-image", "") === "data:image/png;base64,dGVzdA==",
      "Ikonka YouTube jest trwale przechowywana w lokalnej bazie.",
    );
    const simultaneousA = {
      ...base,
      videoId: "multi-tab-a01",
      sessionId: "simultaneous-tab-a",
      sequence: 1,
      seconds: 5,
      mediaSeconds: 5,
    };
    const simultaneousB = {
      ...base,
      videoId: "multi-tab-b01",
      sessionId: "simultaneous-tab-b",
      sequence: 1,
      seconds: 5,
      mediaSeconds: 5,
    };
    const [savedA, savedB] = await Promise.all([
      VtmStorage.saveWatchEvent(simultaneousA, 101),
      VtmStorage.saveWatchEvent(simultaneousB, 202),
    ]);
    assert(
      savedA.seconds + savedB.seconds === 5,
      "Równocześnie odtwarzane karty zapisują łącznie tylko jeden rzeczywisty czas.",
    );
    assert(
      (await VtmStorage.getAllHistory())
        .filter((row) => row.videoId.startsWith("multi-tab-"))
        .reduce((sum, row) => sum + row.mediaSeconds, 0) === 10,
      "Czas filmu jest sumowany z obu równocześnie odtwarzanych kart.",
    );
    assert(
      (await VtmStorage.getAllHistory()).some((row) => row.videoId.startsWith("multi-tab-") && row.seconds === 0 && row.mediaSeconds === 5),
      "Druga karta zachowuje własny czas filmu bez podwajania czasu rzeczywistego.",
    );
    const ownerTab = savedA.seconds > 0 ? 101 : 202;
    const nextOwnerEvent = savedA.seconds > 0
      ? { ...simultaneousB, sequence: 2, seconds: 3, mediaSeconds: 6 }
      : { ...simultaneousA, sequence: 2, seconds: 3, mediaSeconds: 6 };
    await VtmStorage.releasePlaybackOwner(ownerTab);
    const nextOwner = await VtmStorage.saveWatchEvent(
      nextOwnerEvent,
      savedA.seconds > 0 ? 202 : 101,
    );
    assert(nextOwner.seconds === 3, "Karta przejmuje naliczanie czasu po zwolnieniu blokady przez poprzednią kartę.");
    const database = await VtmStorage.openDatabase();
    const cleanup = database.transaction(["videos", "sessions", "settings", "playback"], "readwrite");
    for (const store of ["videos", "sessions", "settings", "playback"]) cleanup.objectStore(store).clear();
    await new Promise((resolve, reject) => {
      cleanup.oncomplete = resolve;
      cleanup.onerror = () => reject(cleanup.error);
      cleanup.onabort = () => reject(cleanup.error);
    });
    output.textContent = checks.join("\n");
    output.dataset.result = "passed";
  }

  run().catch((error) => {
    console.error(error);
    output.textContent = `FAILED: ${error.message}\n${checks.join("\n")}`;
    output.dataset.result = "failed";
  });
})();
